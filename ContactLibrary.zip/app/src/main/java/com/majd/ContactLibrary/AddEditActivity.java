package com.majd.ContactLibrary;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.majd.store.R;

public class AddEditActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPhone, etWebsite;
    private ImageView imgPreview;
    private MaterialButton btnIcon, btnSave;
    private ChipGroup chipsGroup;
    private int avatarRes = R.drawable.ic_avatar_1;
    private int position = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_add_edit);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etWebsite = findViewById(R.id.etWebsite);
        imgPreview = findViewById(R.id.imgPreview);
        btnIcon = findViewById(R.id.btnPickImg);
        btnSave = findViewById(R.id.btnSave);
        chipsGroup = findViewById(R.id.chipsGroup);

        Contact incoming = getIntent().getParcelableExtra(MainActivity.EXTRA_CONTACT);
        position = getIntent().getIntExtra(MainActivity.EXTRA_POSITION, -1);

        if (incoming != null) {
            etName.setText(incoming.getName());
            etEmail.setText(incoming.getEmail());
            etPhone.setText(incoming.getPhone());
            etWebsite.setText(incoming.getWebsite());
            avatarRes = incoming.getAvatarRes();
            imgPreview.setImageResource(avatarRes);
            selectChipByGroup(incoming.getGroup());
        } else {
            selectChipByGroup("Friends");
        }

        btnIcon.setOnClickListener(v -> {
            if (avatarRes == R.drawable.ic_avatar_1) avatarRes = R.drawable.ic_avatar_2;
            else if (avatarRes == R.drawable.ic_avatar_2) avatarRes = R.drawable.ic_avatar_3;
            else avatarRes = R.drawable.ic_avatar_1;
            imgPreview.setImageResource(avatarRes);
        });

        btnSave.setOnClickListener(v -> {
            String name = t(etName);
            String email = t(etEmail);
            String phone = t(etPhone);
            String web = t(etWebsite);

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone)) {
                Toast.makeText(this, "Name & Phone required", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(web)) web = "https://example.com";
            if (TextUtils.isEmpty(email)) email = "support@example.com";

            String group = getSelectedGroup();
            if (TextUtils.isEmpty(group) || "All".equalsIgnoreCase(group)) {
                group = "Friends";
            }

            Contact c = new Contact(name, email, phone, web, avatarRes, group);

            Intent data = new Intent();
            data.putExtra(MainActivity.EXTRA_CONTACT, c);
            data.putExtra(MainActivity.EXTRA_POSITION, position);
            setResult(RESULT_OK, data);
            finish();
        });
    }

    private String t(TextInputEditText e){
        return e.getText()==null? "" : e.getText().toString().trim();
    }

    private void selectChipByGroup(String g){
        if (g == null) return;
        g = g.trim();
        for (int i = 0; i < chipsGroup.getChildCount(); i++){
            Chip ch = (Chip) chipsGroup.getChildAt(i);
            if (ch.getText()!=null && ch.getText().toString().equalsIgnoreCase(g)){
                ch.setChecked(true);
            } else if ("All".equalsIgnoreCase(g)) {
                if (ch.getText()!=null && "All".equalsIgnoreCase(ch.getText().toString())) ch.setChecked(true);
            }
        }
    }

    private String getSelectedGroup(){
        int id = chipsGroup.getCheckedChipId();
        if (id == -1) return "";
        Chip ch = chipsGroup.findViewById(id);
        return ch != null && ch.getText()!=null ? ch.getText().toString() : "";
    }
}
