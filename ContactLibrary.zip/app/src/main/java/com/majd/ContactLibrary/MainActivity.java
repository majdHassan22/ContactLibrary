package com.majd.ContactLibrary;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.majd.store.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final int REQ_ADD = 1;
    public static final int REQ_EDIT = 2;

    public static final String EXTRA_CONTACT = "contact";
    public static final String EXTRA_POSITION = "pos";

    private RecyclerView rv;
    private ContactAdapter adapter;
    private ArrayList<Contact> contacts = new ArrayList<>();
    private ImageButton btnToggle;
    private TextInputEditText etSearch;
    private ChipGroup chips;
    private TextView counter;

    @Override
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        rv = findViewById(R.id.recycler);
        btnToggle = findViewById(R.id.btnToggle);
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        etSearch = findViewById(R.id.etSearch);
        chips = findViewById(R.id.chips);
        counter = findViewById(R.id.counter);

        seed();

        adapter = new ContactAdapter(this, contacts, (c, pos) -> {
            Intent i = new Intent(MainActivity.this, DetailsActivity.class);
            i.putExtra(EXTRA_CONTACT, c);
            i.putExtra(EXTRA_POSITION, pos);
            startActivityForResult(i, REQ_EDIT);
            adapter.setOnDataChanged(count -> counter.setText("Total: " + count + " contacts"));
        });
        adapter.setHasStableIds(true);

        rv.setAdapter(adapter);

        applyLayout(Prefs.isGrid(this));

        btnToggle.setOnClickListener(v -> {
            boolean wantGrid = !(rv.getLayoutManager() instanceof GridLayoutManager);
            Prefs.setGrid(this, wantGrid);
            applyLayout(wantGrid);
            Toast.makeText(this, wantGrid ? "Grid" : "List", Toast.LENGTH_SHORT).show();
        });

        fab.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, AddEditActivity.class);
            startActivityForResult(i, REQ_ADD);
        });
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.setQuery(s==null? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        chips.setOnCheckedChangeListener((group, checkedId) -> {
            String sel = "All";
            if (checkedId == View.NO_ID) { sel = "All"; }
            else {
                Chip ch = group.findViewById(checkedId);
                if (ch != null) sel = ch.getText().toString();
            }
            adapter.setGroupFilter(sel);
        });
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override public boolean onMove(RecyclerView r, RecyclerView.ViewHolder v, RecyclerView.ViewHolder t) { return false; }
            @Override public void onSwiped(RecyclerView.ViewHolder v, int dir) {
                int p = v.getAdapterPosition();
                Contact removed = adapter.remove(p);
                Snackbar.make(rv, "Deleted: " + removed.getName(), Snackbar.LENGTH_LONG).show();
            }
        }).attachToRecyclerView(rv);
        adapter.setOnDataChanged(count -> counter.setText("Total: " + count + " contacts"));
    }



    private void seed() {
        contacts.add(new Contact("Ahmed Ali", "ahmed@example.com", "+970590000001",
                "https://example.com", R.drawable.ic_avatar_1, "Work"));

        contacts.add(new Contact("Sara Omar", "sara@example.com", "+970590000002",
                "https://example.com", R.drawable.ic_avatar_2, "Family"));

        contacts.add(new Contact("Yousef Zaki", "yousef@example.com", "+970590000003",
                "https://example.com", R.drawable.ic_avatar_3, "Friends"));

    }
    private void applyLayout(boolean grid){
        rv.setLayoutManager(grid ? new GridLayoutManager(this, 2) : new LinearLayoutManager(this));
        btnToggle.setImageResource(grid ? R.drawable.ic_view_list : R.drawable.ic_view_grid);
        adapter.setGridMode(grid);
    }

    @Override
    protected void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;

        Contact c = data.getParcelableExtra(EXTRA_CONTACT);
        int pos = data.getIntExtra(EXTRA_POSITION, -1);

        if (req == REQ_ADD && c != null) {
            adapter.add(c);
            rv.scrollToPosition(0);
            Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
        } else if (req == REQ_EDIT) {
            String action = data.getStringExtra("action");
            if ("delete".equals(action) && pos >= 0) {
                adapter.remove(pos);
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
            } else if ("edit".equals(action) && c != null && pos >= 0) {
                adapter.update(pos, c);
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
