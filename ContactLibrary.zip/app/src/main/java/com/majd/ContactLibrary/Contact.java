package com.majd.ContactLibrary;

import android.os.Parcel;
import android.os.Parcelable;

public class Contact implements Parcelable {
    private String name;
    private String email;
    private String phone;
    private String website;
    private int avatarRes;
    private String group;


    public Contact(String name, String email, String phone, String website, int avatarRes, String group) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.website = website;
        this.avatarRes = avatarRes;
        this.group = group == null ? "Friends" : group;
    }

    protected Contact(Parcel in) {
        name = in.readString();
        email = in.readString();
        phone = in.readString();
        website = in.readString();
        avatarRes = in.readInt();
        group = in.readString();
    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override public Contact createFromParcel(Parcel in) { return new Contact(in); }
        @Override public Contact[] newArray(int size) { return new Contact[size]; }
    };

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getWebsite() { return website; }
    public int getAvatarRes() { return avatarRes; }
    public String getGroup() { return group; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setWebsite(String website) { this.website = website; }
    public void setAvatarRes(int avatarRes) { this.avatarRes = avatarRes; }
    public void setGroup(String group) { this.group = group; }
    @Override public int describeContents() { return 0; }


    @Override public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(email);
        dest.writeString(phone);
        dest.writeString(website);
        dest.writeInt(avatarRes);
        dest.writeString(group);
    }
}
