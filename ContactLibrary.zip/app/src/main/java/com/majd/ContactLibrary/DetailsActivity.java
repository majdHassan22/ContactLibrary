package com.majd.ContactLibrary;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.majd.store.R;

public class DetailsActivity extends AppCompatActivity {

    private Contact c;
    private int pos;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_details);

        c = getIntent().getParcelableExtra(MainActivity.EXTRA_CONTACT);
        pos = getIntent().getIntExtra(MainActivity.EXTRA_POSITION, -1);

        ImageView img = findViewById(R.id.imgContact);
        TextView name = findViewById(R.id.tvName);
        TextView phone = findViewById(R.id.tvPhone);
        TextView email = findViewById(R.id.tvEmail);
        TextView web = findViewById(R.id.tvWebsite);

        ImageButton btnCall = findViewById(R.id.btnCall);
        ImageButton btnEmail = findViewById(R.id.btnEmail);
        ImageButton btnWeb = findViewById(R.id.btnWebsite);
        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);

        img.setImageResource(c.getAvatarRes());
        name.setText(c.getName());
        phone.setText(c.getPhone());
        email.setText(c.getEmail());
        web.setText(c.getWebsite());

        btnCall.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.getPhone()))));
        btnEmail.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + c.getEmail()))));
        btnWeb.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(c.getWebsite()))));

        btnEdit.setOnClickListener(v -> {
            Intent i = new Intent(DetailsActivity.this, AddEditActivity.class);
            i.putExtra(MainActivity.EXTRA_CONTACT, c);
            i.putExtra(MainActivity.EXTRA_POSITION, pos);
            startActivityForResult(i, MainActivity.REQ_EDIT);
        });

        btnDelete.setOnClickListener(v -> {
            Intent data = new Intent();
            data.putExtra("action", "delete");
            data.putExtra(MainActivity.EXTRA_POSITION, pos);
            setResult(RESULT_OK, data);
            finish();
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res == RESULT_OK && data != null && req == MainActivity.REQ_EDIT) {
            Contact updated = data.getParcelableExtra(MainActivity.EXTRA_CONTACT);
            int p = data.getIntExtra(MainActivity.EXTRA_POSITION, -1);
            if (updated != null && p >= 0) {
                Intent back = new Intent();
                back.putExtra("action", "edit");
                back.putExtra(MainActivity.EXTRA_CONTACT, updated);
                back.putExtra(MainActivity.EXTRA_POSITION, p);
                setResult(RESULT_OK, back);
                finish();
            }
        }
    }
}
