package com.majd.ContactLibrary;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


import com.majd.store.R;

import java.util.ArrayList;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.Holder> implements Filterable {

    public interface OnItemClick { void onClick(Contact c, int pos); }
    public interface OnDataChanged { void onChanged(int count); }

    private Context context;
    private ArrayList<Contact> original;
    private ArrayList<Contact> data;
    private OnItemClick listener;
    private OnDataChanged dataChanged;

    private String query = "";
    private String group = "All";
    private boolean gridMode = false;


    public ContactAdapter(Context context, ArrayList<Contact> data, OnItemClick listener) {
        this.context = context;
        this.original = new ArrayList<>(data);
        this.data = new ArrayList<>(data);
        this.listener = listener;
    }

    public void setOnDataChanged(OnDataChanged l){ this.dataChanged = l; }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = (viewType == 1) ? R.layout.item_contact_grid : R.layout.item_contact_list;
        View v = LayoutInflater.from(context).inflate(layout, parent, false);
        return new Holder(v);
    }

    @Override public long getItemId(int position) {
        Contact c = data.get(position);
        return (c.getPhone() != null ? c.getPhone() : c.getName()).hashCode();
    }


    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Contact c = data.get(position);
        h.name.setText(c.getName());
        h.phone.setText(c.getPhone());
        h.email.setText(c.getEmail());
        h.avatar.setImageResource(c.getAvatarRes());
        h.card.setOnClickListener(v -> { if (listener != null) listener.onClick(c, h.getAdapterPosition()); });
    }
    public void setGridMode(boolean grid){
        this.gridMode = grid;
        notifyDataSetChanged();
    }

    @Override public int getItemViewType(int position) {
        return gridMode ? 1 : 0;
    }

    @Override public int getItemCount() { return data.size(); }
    public Contact getItem(int pos){ return data.get(pos); }

    public void add(Contact c){
        original.add(0, c);
        applyFilter();
        notifyDataSetChanged();
    }

    public void update(int posInCurrent, Contact c){
        Contact old = data.get(posInCurrent);
        int idx = original.indexOf(old);
        if (idx >= 0) original.set(idx, c);
        applyFilter();
        notifyDataSetChanged();
    }

    public Contact remove(int posInCurrent){
        Contact target = data.get(posInCurrent);
        original.remove(target);
        applyFilter();
        notifyItemRemoved(posInCurrent);
        return target;
    }

    public void setQuery(String q){
        this.query = q == null ? "" : q.trim().toLowerCase();
        applyFilter();
        notifyDataSetChanged();
    }

    public void setGroupFilter(String group){
        this.group = (group == null) ? "All" : group;
        applyFilter();
        notifyDataSetChanged();
    }

    private void applyFilter(){
        ArrayList<Contact> filtered = new ArrayList<>();
        for (Contact c : original){
            boolean matchesText =
                    query.isEmpty()
                            || (c.getName()!=null && c.getName().toLowerCase().contains(query))
                            || (c.getPhone()!=null && c.getPhone().toLowerCase().contains(query));
            boolean matchesGroup = "All".equals(group) || group.equalsIgnoreCase(c.getGroup());
            if (matchesText && matchesGroup) filtered.add(c);
        }
        data.clear();
        data.addAll(filtered);
        if (dataChanged != null) dataChanged.onChanged(data.size());
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override protected FilterResults performFiltering(CharSequence constraint) { return new FilterResults(); }
            @Override protected void publishResults(CharSequence constraint, FilterResults results) {}
        };
    }

    static class Holder extends RecyclerView.ViewHolder {
        CardView card; ImageView avatar; TextView name, phone, email;
        Holder(@NonNull View v) {
            super(v);
            card = v.findViewById(R.id.card);
            avatar = v.findViewById(R.id.imgAvatar);
            name = v.findViewById(R.id.txtName);
            phone = v.findViewById(R.id.txtPhone);
            email = v.findViewById(R.id.txtEmail);
        }
    }
}
