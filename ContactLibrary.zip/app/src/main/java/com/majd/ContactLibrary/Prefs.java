package com.majd.ContactLibrary;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static final String FILE = "prefs";
    private static final String KEY_LAYOUT = "layout";

    public static void setGrid(Context c, boolean grid) {
        SharedPreferences sp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_LAYOUT, grid).apply();
    }

    public static boolean isGrid(Context c) {
        SharedPreferences sp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        return sp.getBoolean(KEY_LAYOUT, false);
    }
}
